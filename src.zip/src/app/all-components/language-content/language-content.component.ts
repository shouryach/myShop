import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-content',
  templateUrl: './language-content.component.html',
  styleUrls: ['./language-content.component.scss'],
})
export class LanguageContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
