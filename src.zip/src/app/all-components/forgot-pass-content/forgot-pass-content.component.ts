import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-pass-content',
  templateUrl: './forgot-pass-content.component.html',
  styleUrls: ['./forgot-pass-content.component.scss'],
})
export class ForgotPassContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
