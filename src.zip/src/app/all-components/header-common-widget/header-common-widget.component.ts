import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-common-widget',
  templateUrl: './header-common-widget.component.html',
  styleUrls: ['./header-common-widget.component.scss'],
})
export class HeaderCommonWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
