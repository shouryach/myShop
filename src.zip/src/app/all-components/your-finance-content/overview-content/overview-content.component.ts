import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overview-content',
  templateUrl: './overview-content.component.html',
  styleUrls: ['./overview-content.component.scss'],
})
export class OverviewContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
