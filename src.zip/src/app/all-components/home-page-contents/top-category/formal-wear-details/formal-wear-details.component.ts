import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formal-wear-details',
  templateUrl: './formal-wear-details.component.html',
  styleUrls: ['./formal-wear-details.component.scss'],
})
export class FormalWearDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
