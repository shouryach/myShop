import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-wear-details',
  templateUrl: './bottom-wear-details.component.html',
  styleUrls: ['./bottom-wear-details.component.scss'],
})
export class BottomWearDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
