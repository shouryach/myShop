import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-category',
  templateUrl: './top-category.component.html',
  styleUrls: ['./top-category.component.scss'],
})
export class TopCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
