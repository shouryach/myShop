import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wear-details',
  templateUrl: './wear-details.component.html',
  styleUrls: ['./wear-details.component.scss'],
})
export class WearDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
