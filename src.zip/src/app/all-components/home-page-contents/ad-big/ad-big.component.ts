import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-big',
  templateUrl: './ad-big.component.html',
  styleUrls: ['./ad-big.component.scss'],
})
export class AdBigComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
