import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-ad',
  templateUrl: './bank-ad.component.html',
  styleUrls: ['./bank-ad.component.scss'],
})
export class BankAdComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
