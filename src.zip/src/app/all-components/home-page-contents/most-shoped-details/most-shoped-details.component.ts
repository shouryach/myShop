import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-most-shoped-details',
  templateUrl: './most-shoped-details.component.html',
  styleUrls: ['./most-shoped-details.component.scss'],
})
export class MostShopedDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
