import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-social',
  templateUrl: './register-social.component.html',
  styleUrls: ['./register-social.component.scss'],
})
export class RegisterSocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
