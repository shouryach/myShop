import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-main-form',
  templateUrl: './register-main-form.component.html',
  styleUrls: ['./register-main-form.component.scss'],
})
export class RegisterMainFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
