import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-otp-register-content',
  templateUrl: './verify-otp-register-content.component.html',
  styleUrls: ['./verify-otp-register-content.component.scss'],
})
export class VerifyOtpRegisterContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
