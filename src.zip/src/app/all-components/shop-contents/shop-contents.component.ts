import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-contents',
  templateUrl: './shop-contents.component.html',
  styleUrls: ['./shop-contents.component.scss'],
})
export class ShopContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
