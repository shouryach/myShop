import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-orders-content',
  templateUrl: './your-orders-content.component.html',
  styleUrls: ['./your-orders-content.component.scss'],
})
export class YourOrdersContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
