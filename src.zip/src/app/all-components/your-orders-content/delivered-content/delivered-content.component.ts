import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivered-content',
  templateUrl: './delivered-content.component.html',
  styleUrls: ['./delivered-content.component.scss'],
})
export class DeliveredContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
