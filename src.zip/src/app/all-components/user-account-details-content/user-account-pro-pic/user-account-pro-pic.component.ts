import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-account-pro-pic',
  templateUrl: './user-account-pro-pic.component.html',
  styleUrls: ['./user-account-pro-pic.component.scss'],
})
export class UserAccountProPicComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
