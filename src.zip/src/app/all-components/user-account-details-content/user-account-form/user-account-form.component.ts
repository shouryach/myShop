import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-account-form',
  templateUrl: './user-account-form.component.html',
  styleUrls: ['./user-account-form.component.scss'],
})
export class UserAccountFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
