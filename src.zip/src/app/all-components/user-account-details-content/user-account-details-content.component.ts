import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-account-details-content',
  templateUrl: './user-account-details-content.component.html',
  styleUrls: ['./user-account-details-content.component.scss'],
})
export class UserAccountDetailsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
