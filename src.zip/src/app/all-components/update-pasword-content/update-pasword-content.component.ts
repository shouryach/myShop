import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-pasword-content',
  templateUrl: './update-pasword-content.component.html',
  styleUrls: ['./update-pasword-content.component.scss'],
})
export class UpdatePaswordContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
