import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-new-bank-details-content',
  templateUrl: './ad-new-bank-details-content.component.html',
  styleUrls: ['./ad-new-bank-details-content.component.scss'],
})
export class AdNewBankDetailsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
