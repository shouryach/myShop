import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-settings-content-details',
  templateUrl: './profile-settings-content-details.component.html',
  styleUrls: ['./profile-settings-content-details.component.scss'],
})
export class ProfileSettingsContentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
