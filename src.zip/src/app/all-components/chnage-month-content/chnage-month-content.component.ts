import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chnage-month-content',
  templateUrl: './chnage-month-content.component.html',
  styleUrls: ['./chnage-month-content.component.scss'],
})
export class ChnageMonthContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
