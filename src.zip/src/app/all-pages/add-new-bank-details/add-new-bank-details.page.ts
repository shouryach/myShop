import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-bank-details',
  templateUrl: './add-new-bank-details.page.html',
  styleUrls: ['./add-new-bank-details.page.scss'],
})
export class AddNewBankDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
