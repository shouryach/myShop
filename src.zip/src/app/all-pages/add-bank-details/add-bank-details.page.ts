import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bank-details',
  templateUrl: './add-bank-details.page.html',
  styleUrls: ['./add-bank-details.page.scss'],
})
export class AddBankDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
